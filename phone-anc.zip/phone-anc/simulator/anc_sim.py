"""
Offline ANC simulator (SIMULATED results only - not measured on any phone).

Models a feedforward ANC loop:
  noise source -> primary path (delay d_p samples) -> disturbance d at the ear
  reference mic hears the noise with no delay (idealised)
  controller output -> secondary path S (pure delay + mild low-pass)
                       -> adds to the disturbance at the ear
  error mic at the ear measures e = d + S*y (plus small sensor noise)

Two controllers:
  1. Broadband NLMS-FxLMS on the reference-mic signal. Cancellation needs
     causality: secondary-path delay must be shorter than the primary
     (noise-to-ear) delay.
  2. Narrowband FxLMS using synthesised sin/cos references at a known tone
     frequency. Delay is compensated by the filtered reference, but the
     step size must shrink as loop delay grows or the loop goes unstable.

Reports steady-state attenuation in dB (negative = quieter at the ear).
"""
import numpy as np

FS = 48000
SENSOR_NOISE_DB = -60.0  # error-mic noise floor relative to unit-power noise


def lowpass_ir(n=32, fc=4000.0):
    t = np.arange(n) - (n - 1) / 2
    h = np.sinc(2 * fc / FS * t) * np.hanning(n)
    return h / h.sum()


def secondary_path(delay_samples):
    """Speaker->ear path: pure delay + one-pole 4 kHz low-pass.

    One-pole (not linear-phase FIR) so the filter itself adds only ~1.5
    samples (~0.03 ms) of group delay; the labelled delay is the real delay.
    """
    a = np.exp(-2 * np.pi * 4000.0 / FS)
    h = (1 - a) * a ** np.arange(24)
    ir = np.zeros(len(h) + delay_samples)
    ir[delay_samples:] = h
    return ir


def attenuation_db(d, e, tail=0.25):
    n = int(len(d) * tail)
    return 10 * np.log10((np.mean(e[-n:] ** 2) + 1e-20) / (np.mean(d[-n:] ** 2) + 1e-20))


def run_broadband(noise, sec_delay_ms, primary_delay_ms, taps=64, mu=0.1, seed=1):
    rng = np.random.default_rng(seed)
    dp = int(round(primary_delay_ms * 1e-3 * FS))
    ds = int(round(sec_delay_ms * 1e-3 * FS))
    s = secondary_path(ds)
    ls = len(s)
    n = len(noise)
    d = np.concatenate([np.zeros(dp), noise])[:n]
    sensor = rng.standard_normal(n) * 10 ** (SENSOR_NOISE_DB / 20)
    # filtered reference (perfect secondary-path estimate)
    fx = np.convolve(noise, s)[:n]
    w = np.zeros(taps)
    y = np.zeros(n)
    e = np.zeros(n)
    mu = mu / (1 + ds / 16.0)  # FxLMS stability: shrink step with loop delay
    for i in range(n):
        lo = max(0, i - taps + 1)
        xv = noise[lo:i + 1][::-1]
        k = len(xv)
        y[i] = w[:k] @ xv
        # anti-noise at ear = sum over secondary path of past outputs
        lo_s = max(0, i - ls + 1)
        yv = y[lo_s:i + 1][::-1]
        anti = s[:len(yv)] @ yv
        e[i] = d[i] + anti + sensor[i]
        fv = fx[lo:i + 1][::-1]
        norm = fv @ fv + 1e-3
        w[:k] -= mu * e[i] * fv / norm
    return d, e


def run_narrowband(freq, sec_delay_ms, n=FS * 4, seed=1):
    rng = np.random.default_rng(seed)
    ds = int(round(sec_delay_ms * 1e-3 * FS))
    s = secondary_path(ds)
    ls = len(s)
    idx = np.arange(n)
    w_ = 2 * np.pi * freq / FS
    d = np.sin(w_ * idx + 0.7)
    sensor = rng.standard_normal(n) * 10 ** (SENSOR_NOISE_DB / 20)
    S = np.sum(s * np.exp(-1j * w_ * np.arange(ls)))
    Sm, Sp = np.abs(S), np.angle(S)
    xs, xc = np.sin(w_ * idx), np.cos(w_ * idx)
    fxs = Sm * np.sin(w_ * idx + Sp)
    fxc = Sm * np.cos(w_ * idx + Sp)
    # FxLMS with delay needs mu roughly inversely proportional to loop delay
    mu = min(0.05, 0.4 / (ds + 20))
    a = b = 0.0
    y = np.zeros(n)
    e = np.zeros(n)
    for i in range(n):
        y[i] = a * xs[i] + b * xc[i]
        lo = max(0, i - ls + 1)
        yv = y[lo:i + 1][::-1]
        e[i] = d[i] + s[:len(yv)] @ yv + sensor[i]
        norm = fxs[i] ** 2 + fxc[i] ** 2 + 1e-6
        a -= mu * e[i] * fxs[i] / norm
        b -= mu * e[i] * fxc[i] / norm
    return d, e


if __name__ == "__main__":
    rng = np.random.default_rng(0)
    print("SIMULATED results (not measured on hardware)")
    print(f"Error-mic sensor noise floor {SENSOR_NOISE_DB} dB, fs={FS} Hz\n")

    noise = rng.standard_normal(FS * 2)
    noise = np.convolve(noise, lowpass_ir(129, 4000.0), mode="same")
    noise /= noise.std()

    print("Broadband noise (band-limited 4 kHz), 2 s")
    print("Sanity case: primary delay 0.5 ms (mic well ahead of ear), "
          "secondary delay swept")
    print(f"{'sec delay ms':>13} {'atten dB':>9}")
    for dms in [0.02, 0.1, 0.25, 0.5, 1, 2, 5, 10, 20]:
        d, e = run_broadband(noise, dms, primary_delay_ms=0.5)
        print(f"{dms:13.2f} {attenuation_db(d, e):9.1f}")

    print("\nRealistic case: primary delay 0.1 ms (mic at the ear)")
    print(f"{'sec delay ms':>13} {'atten dB':>9}")
    for dms in [0.02, 0.05, 0.5, 5, 20]:
        d, e = run_broadband(noise, dms, primary_delay_ms=0.1)
        print(f"{dms:13.2f} {attenuation_db(d, e):9.1f}")

    print("\nNarrowband FxLMS on steady tones, 4 s")
    freqs = [60, 120, 200, 500]
    print(f"{'delay ms':>9} " + " ".join(f"{f:>7}Hz" for f in freqs))
    for dms in [0.5, 1, 2, 5, 10, 20, 40]:
        row = [attenuation_db(*run_narrowband(f, dms)) for f in freqs]
        print(f"{dms:9.1f} " + " ".join(f"{v:9.1f}" for v in row))
