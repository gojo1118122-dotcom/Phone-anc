# Phone ANC (experimental prototype)

Uses an Android phone as the DSP engine for active noise cancellation on wired
USB-C earphones. **This is a research prototype, not a finished ANC product.**
Read "What works / what does not" before expecting anything from it.

## Status: what has and has not been verified

| Item | Status |
|---|---|
| Offline simulation of cancellation vs delay (`simulator/`) | Run. **Simulated**, not measured. |
| DSP core `dsp.h` (FxLMS, path ID, latency meter) | Compiled and run on a desktop PC against a simulated loop (`host_test/`). **Simulated**. |
| `AncEngine.cpp` (Oboe engine + JNI) | Syntax-checked against the real Oboe 1.9.3 headers. **Not linked, not run.** |
| Kotlin UI, Gradle files, manifest, layout | Written. XML well-formed. **Not compiled.** |
| APK | **Not built.** No Android SDK/NDK was available where this was written. |
| Any measurement on a Nothing Phone 3a or any phone | **None.** The tables below are empty on purpose. |

## Build

1. Install Android Studio (free) with SDK Platform 35 and the NDK + CMake 3.22.1
   (SDK Manager > SDK Tools).
2. Open this folder (`phone-anc/`) in Android Studio. No Gradle wrapper is
   included; accept Android Studio's default Gradle (8.9 or newer) when
   prompted, or run `gradle wrapper` once in this folder.
3. Let it sync (downloads Oboe 1.9.3 from Maven Central), then Run on a
   connected phone with USB debugging on. Or `Build > Build APK(s)`.
4. Expect a possible first-build fix or two; the native and Kotlin code have
   never been compiled by the real toolchain.

Optional desktop checks (no Android needed, needs numpy and g++):

```
python3 simulator/anc_sim.py                 # ~35 s
cd host_test && g++ -O2 -std=c++17 -I../app/src/main/cpp host_test.cpp -o host_test && ./host_test
```

## Project layout

```
app/src/main/cpp/dsp.h          DSP core, no Android dependency (FxLMS, path ID, latency meter)
app/src/main/cpp/AncEngine.cpp  Oboe full-duplex engine, safety guards, JNI
app/src/main/java/.../          MainActivity (UI), NativeBridge (JNI)
simulator/anc_sim.py            Offline simulation + results_simulated.txt
host_test/host_test.cpp         Runs dsp.h against a simulated loop + results_host_simulated.txt
```

## How to test on a phone (this is what produces real numbers)

Start with the output limit at its lowest setting and raise it slowly.

1. Plug in the USB-C earphones/adapter. Pick them as both input and output.
2. **Open audio streams.** Check the stats panel: API (AAudio expected),
   sharing mode (Exclusive vs Shared), burst size, input preset granted. If
   the input or output opens as Shared or the preset falls back, that is a
   real finding for your device.
3. **Measure round-trip latency.** Needs the mic to hear the speaker (put the
   earbud against the mic or wear it with the mic near the speaker). Run it a
   few times and record mean/min/max. Accuracy is roughly one burst; cross-check
   with Google's free OboeTester app.
4. **Identify path.** Plays low-level hiss for 4 s. Check the "PATH ID" line.
   If it says "NOT usable", the mic does not hear the speaker clearly and ANC
   will not work with this earphone.
5. **Start narrowband ANC** while a steady tone (set the same frequency in the
   field) plays from an external speaker. Watch the mic level and your ears.

Record results here:

### Round-trip latency (measured)

| Device | Earphone/adapter | Burst (frames) | Buffer setting | Mean ms | Min ms | Max ms |
|---|---|---|---|---|---|---|
| _not yet measured_ | | | | | | |

### Cancellation (measured)

| Device | Earphone | Tone Hz | Attenuation dB (by measurement) | Notes |
|---|---|---|---|---|
| _not yet measured_ | | | | |

### Tested devices and limitations

| Device | Android | Result |
|---|---|---|
| Nothing Phone 3a | | _untested_ |

## Simulation results (SIMULATED, from the code in this repo)

Error-mic noise floor -60 dB. "Attenuation" is residual noise at the ear
relative to the original, negative is quieter.

Broadband noise, anti-noise path delay swept (noise reaches the ear 0.1 ms
after the reference mic):

| Anti-noise path delay | Attenuation |
|---|---|
| 0.02 ms | -42.9 dB |
| 0.05 ms | -36.3 dB |
| 0.5 ms | +0.5 dB (no benefit) |
| 5 ms | +0.2 dB |
| 20 ms | 0.0 dB |

Narrowband FxLMS on a steady tone (path known/identified, exact frequency, no
frequency drift): -57 dB at every tested delay from 0.5 to 40 ms and every
tested tone from 60 to 500 Hz. That figure is limited by the assumed sensor
noise floor. **It is an upper bound under ideal conditions**, not a prediction
for real earphones, real tone drift, or real speaker/ear acoustics.

The same code in `host_test/` reproduces this behaviour, including a 25 ms
loop identified with a delayed probe (`results_host_simulated.txt`).

## What works / what does not

- **Broadband ANC through a USB-C round trip does not work.** The anti-noise
  must reach the ear within a fraction of a millisecond. Android loops are
  typically tens of milliseconds (to be measured on your phone). The simulation
  shows cancellation vanishes once the path is longer than about the noise's
  own travel time.
- **Steady, periodic noise (hum, drone) is the realistic target.** Narrowband
  FxLMS compensates delay because the reference is synthesised, not heard.
- **Mic placement decides everything.** The controller needs a mic at the ear
  (error sensor) and a measurable speaker-to-mic path. Earphones whose mic is
  in the cable remote hear the room, not the ear, and the path-ID step will
  report "not usable". Alternatives: earphones with a mic in the earpiece, a
  small external mic placed in/at the ear cup, or the phone's own mic for
  experiments.
- **Android's call noise suppression is not ANC** and is not used. The input
  preset is UNPROCESSED where the device grants it, with fallbacks that are
  reported in the stats.
- **Not every phone exposes the same audio hardware.** Exclusive mode,
  unprocessed input, low-latency USB paths, and duplex over one USB device all
  vary by phone and by the earphone/adapter's USB audio implementation.
  The stats panel shows what was actually granted.
- Bluetooth is not supported and is labelled as unsuitable in the device list.
- The app stops all audio when it leaves the foreground. There is no
  background/foreground-service mode.

## Safety

- Output is hard-capped at 15% of full scale in the native engine regardless
  of the UI; default is 3%. Output ramps in over 0.25 s.
- STOP silences the next audio callback and closes both streams.
- Auto-stop if the mic stays pinned near full scale (feedback) or the output
  saturates repeatedly (controller not converging).
- An adaptive controller can misbehave. Do not wear earphones during first
  runs of a new configuration; test them against the mic or at arm's length,
  then wear them at the lowest limit.
