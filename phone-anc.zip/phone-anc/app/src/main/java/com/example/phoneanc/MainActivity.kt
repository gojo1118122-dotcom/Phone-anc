package com.example.phoneanc

import android.Manifest
import android.content.pm.PackageManager
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private data class Dev(val id: Int, val label: String)

    private lateinit var audioManager: AudioManager
    private lateinit var spinIn: Spinner
    private lateinit var spinOut: Spinner
    private lateinit var spinBursts: Spinner
    private lateinit var txtStats: TextView
    private lateinit var txtLimit: TextView
    private lateinit var seekLimit: SeekBar
    private lateinit var editFreq: EditText
    private var inputs = listOf<Dev>()
    private var outputs = listOf<Dev>()
    private var streamsOpen = false
    private val ui = Handler(Looper.getMainLooper())

    private val poll = object : Runnable {
        override fun run() {
            txtStats.text = NativeBridge.nativeStats()
            ui.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager

        spinIn = findViewById(R.id.spinIn)
        spinOut = findViewById(R.id.spinOut)
        spinBursts = findViewById(R.id.spinBursts)
        txtStats = findViewById(R.id.txtStats)
        txtLimit = findViewById(R.id.txtLimit)
        seekLimit = findViewById(R.id.seekLimit)
        editFreq = findViewById(R.id.editFreq)

        spinBursts.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("1", "2", "3", "4"))
        spinBursts.setSelection(1)

        seekLimit.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                updateLimitLabel(); pushParams()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        updateLimitLabel()

        findViewById<Button>(R.id.btnStop).setOnClickListener { emergencyStop() }
        findViewById<Button>(R.id.btnStart).setOnClickListener { openStreams() }
        findViewById<Button>(R.id.btnLatency).setOnClickListener { setMode(NativeBridge.MODE_LATENCY) }
        findViewById<Button>(R.id.btnSecPath).setOnClickListener { startPathId() }
        findViewById<Button>(R.id.btnAnc).setOnClickListener { setMode(NativeBridge.MODE_ANC) }
        findViewById<Button>(R.id.btnTone).setOnClickListener { setMode(NativeBridge.MODE_TONE) }

        refreshDevices()
        if (!hasMic()) ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 1)
    }

    override fun onStart() {
        super.onStart()
        ui.post(poll)
    }

    // Never keep making sound in the background.
    override fun onStop() {
        super.onStop()
        ui.removeCallbacks(poll)
        emergencyStop()
    }

    private fun hasMic() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun typeName(t: Int) = when (t) {
        AudioDeviceInfo.TYPE_BUILTIN_MIC -> "built-in mic"
        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "phone speaker"
        AudioDeviceInfo.TYPE_BUILTIN_EARPIECE -> "earpiece"
        AudioDeviceInfo.TYPE_WIRED_HEADSET -> "wired headset"
        AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> "wired headphones"
        AudioDeviceInfo.TYPE_USB_HEADSET -> "USB headset"
        AudioDeviceInfo.TYPE_USB_DEVICE -> "USB device"
        AudioDeviceInfo.TYPE_USB_ACCESSORY -> "USB accessory"
        AudioDeviceInfo.TYPE_BLUETOOTH_SCO, AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> "Bluetooth (not for ANC)"
        else -> "type $t"
    }

    private fun refreshDevices() {
        fun list(flag: Int) = audioManager.getDevices(flag).map {
            Dev(it.id, "${typeName(it.type)} - ${it.productName} (id ${it.id})")
        }
        inputs = list(AudioManager.GET_DEVICES_INPUTS)
        outputs = list(AudioManager.GET_DEVICES_OUTPUTS)
        spinIn.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, inputs.map { it.label })
        spinOut.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, outputs.map { it.label })
        // prefer USB / wired devices
        fun pref(l: List<Dev>) = l.indexOfFirst { it.label.startsWith("USB") || it.label.startsWith("wired") }.coerceAtLeast(0)
        spinIn.setSelection(pref(inputs))
        spinOut.setSelection(pref(outputs))
    }

    private fun limitFraction() = seekLimit.progress / 100f

    private fun updateLimitLabel() {
        txtLimit.text = "Output limit: ${seekLimit.progress}% of full scale (hard cap 15%)"
    }

    private fun freq() = editFreq.text.toString().toFloatOrNull() ?: 100f

    private fun pushParams(probeOffset: Int = lastProbeOffset) {
        lastProbeOffset = probeOffset
        NativeBridge.nativeSetParams(freq(), limitFraction(), 0.5f, probeOffset, 0f)
    }
    private var lastProbeOffset = 0

    private fun openStreams() {
        if (!hasMic()) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            return
        }
        refreshDevices()
        if (inputs.isEmpty() || outputs.isEmpty()) {
            toast("No audio devices found")
            return
        }
        val r = NativeBridge.nativeStart(
            inputs[spinIn.selectedItemPosition].id,
            outputs[spinOut.selectedItemPosition].id,
            spinBursts.selectedItem.toString().toInt()
        )
        streamsOpen = r == 0
        if (r != 0) toast("Could not open streams (oboe result $r). See stats.")
        pushParams()
    }

    private fun setMode(mode: Int) {
        if (!streamsOpen) { toast("Open audio streams first"); return }
        pushParams()
        NativeBridge.nativeSetMode(mode)
    }

    private fun startPathId() {
        if (!streamsOpen) { toast("Open audio streams first"); return }
        // Delay the probe by (measured latency - 32 samples) so a 256-tap
        // identifier covers the real loop delay. Needs a latency measurement.
        val ms = NativeBridge.nativeLatencyMeanMs()
        val fs = NativeBridge.nativeSampleRate()
        val off = if (ms > 0) ((ms * fs / 1000.0).toInt() - 32).coerceAtLeast(0) else 0
        if (ms <= 0) toast("No latency measurement yet: path ID only covers ~5 ms")
        pushParams(off)
        NativeBridge.nativeSetMode(NativeBridge.MODE_SECPATH)
    }

    private fun emergencyStop() {
        NativeBridge.nativeEmergencyStop()
        streamsOpen = false
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (!hasMic()) toast("Microphone permission is required")
    }
}
