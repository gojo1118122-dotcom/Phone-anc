package com.example.phoneanc

/** Thin JNI wrapper around the Oboe engine in src/main/cpp/AncEngine.cpp. */
object NativeBridge {
    init { System.loadLibrary("phoneanc") }

    const val MODE_IDLE = 0
    const val MODE_LATENCY = 1
    const val MODE_SECPATH = 2
    const val MODE_ANC = 3
    const val MODE_TONE = 4

    /** Returns 0 on success, otherwise an oboe::Result code. */
    external fun nativeStart(inputDeviceId: Int, outputDeviceId: Int, bursts: Int): Int
    external fun nativeStop()
    external fun nativeEmergencyStop()
    external fun nativeSetMode(mode: Int)
    external fun nativeSetParams(freqHz: Float, limit: Float, toneGain: Float, probeOffset: Int, phaseDeg: Float)
    external fun nativeLatencyMeanMs(): Double
    external fun nativeSampleRate(): Int
    external fun nativeStats(): String
}
