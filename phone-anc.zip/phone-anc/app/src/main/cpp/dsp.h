// dsp.h - Android-independent DSP core for Phone ANC.
// Header-only so it can be unit-tested on a desktop (see host_test/).
#pragma once
#include <algorithm>
#include <cmath>
#include <complex>
#include <cstdint>
#include <vector>

namespace anc {

inline float clampf(float x, float lim) {
    return x > lim ? lim : (x < -lim ? -lim : x);
}

// Delay line with a doubled buffer: window()[0] is the newest sample and
// window()[0..n-1] is contiguous, so FIR / LMS inner loops need no modulo.
class History {
public:
    explicit History(int n = 1) { resize(n); }
    void resize(int n) {
        n_ = n;
        buf_.assign(2 * n, 0.0f);
        pos_ = 0;
    }
    void push(float x) {
        pos_ = (pos_ == 0) ? n_ - 1 : pos_ - 1;
        buf_[pos_] = x;
        buf_[pos_ + n_] = x;
    }
    const float* window() const { return buf_.data() + pos_; }
    int size() const { return n_; }

private:
    int n_ = 1, pos_ = 0;
    std::vector<float> buf_;
};

// Identifies the secondary path (speaker -> error mic) with NLMS.
// Feed it the probe sample that was sent to the speaker and the mic sample
// captured at the same instant. The error mic must hear the speaker for this
// to mean anything; with a cable-inline mic it identifies the wrong path.
class SecondaryPathId {
public:
    explicit SecondaryPathId(int taps = 256, float mu = 0.3f) { configure(taps, mu); }
    void configure(int taps, float mu) {
        taps_ = taps;
        mu_ = mu;
        w_.assign(taps, 0.0f);
        hist_.resize(taps);
        energy_ = 0.0f;
        samples_ = 0;
        errPow_ = 0.0f;
        micPow_ = 0.0f;
    }
    void process(float probe, float mic) {
        // maintain running energy of the probe window
        float oldest = hist_.window()[taps_ - 1];
        hist_.push(probe);
        energy_ += probe * probe - oldest * oldest;
        if (energy_ < 0.0f) energy_ = 0.0f;
        const float* x = hist_.window();
        float y = 0.0f;
        for (int k = 0; k < taps_; ++k) y += w_[k] * x[k];
        float e = mic - y;
        float g = mu_ * e / (energy_ + 1e-6f);
        for (int k = 0; k < taps_; ++k) w_[k] += g * x[k];
        ++samples_;
        errPow_ += 0.001f * (e * e - errPow_);
        micPow_ += 0.001f * (mic * mic - micPow_);
    }
    // Identification quality: residual power relative to mic power (dB).
    // More negative is better; near 0 dB means the path was not identified
    // (mic does not hear the speaker, or the probe was too quiet).
    float residualDb() const { return 10.0f * std::log10((errPow_ + 1e-12f) / (micPow_ + 1e-12f)); }
    const std::vector<float>& taps() const { return w_; }
    int peakIndex() const {
        int best = 0;
        float bv = 0.0f;
        for (int k = 0; k < taps_; ++k) {
            float a = std::fabs(w_[k]);
            if (a > bv) { bv = a; best = k; }
        }
        return best;
    }
    float peakMagnitude() const {
        float bv = 0.0f;
        for (float v : w_) bv = std::max(bv, std::fabs(v));
        return bv;
    }
    // Complex gain of the identified path at a frequency. If the probe was
    // delayed by `offset` samples before identification (so a short filter
    // can cover a long loop delay), pass that offset so the phase is right.
    std::complex<float> gainAt(float freqHz, float fs, int offset = 0) const {
        std::complex<double> acc(0.0, 0.0);
        double w = 2.0 * M_PI * freqHz / fs;
        for (int k = 0; k < taps_; ++k)
            acc += (double)w_[k] * std::exp(std::complex<double>(0.0, -w * (double)(k + offset)));
        return std::complex<float>((float)acc.real(), (float)acc.imag());
    }
    long samplesSeen() const { return samples_; }

private:
    int taps_ = 256;
    float mu_ = 0.3f, energy_ = 0.0f, errPow_ = 0.0f, micPow_ = 0.0f;
    long samples_ = 0;
    std::vector<float> w_;
    History hist_{1};
};

// Narrowband FxLMS: cancels one steady tone at a known frequency.
// Reference is synthesised (sin/cos), so loop delay is compensated by the
// filtered reference rather than needing the noise to be predicted.
class NarrowbandFxlms {
public:
    void configure(float freqHz, float fs, std::complex<float> S, float baseMu, int loopDelaySamples) {
        w_ = 2.0 * M_PI * freqHz / fs;
        phase_ = 0.0;
        Sm_ = std::abs(S);
        Sp_ = std::arg(S);
        // FxLMS stability: step must shrink with loop delay (see simulator).
        mu_ = std::min(baseMu, 0.4f / (float)(loopDelaySamples + 20));
        a_ = b_ = 0.0f;
        fxs_ = fxc_ = 0.0f;
        valid_ = Sm_ > 1e-4f;
    }
    bool valid() const { return valid_; }
    float step() const { return mu_; }
    // err: error-mic sample for this instant. Returns the anti-noise sample.
    float process(float err) {
        if (!valid_) return 0.0f;
        float s = (float)std::sin(phase_), c = (float)std::cos(phase_);
        fxs_ = Sm_ * (float)std::sin(phase_ + Sp_);
        fxc_ = Sm_ * (float)std::cos(phase_ + Sp_);
        float norm = fxs_ * fxs_ + fxc_ * fxc_ + 1e-6f;
        a_ -= mu_ * err * fxs_ / norm;
        b_ -= mu_ * err * fxc_ / norm;
        float y = a_ * s + b_ * c;
        phase_ += w_;
        if (phase_ > 2.0 * M_PI) phase_ -= 2.0 * M_PI;
        return y;
    }
    float amplitude() const { return std::sqrt(a_ * a_ + b_ * b_); }
    void reset() { a_ = b_ = 0.0f; }

private:
    double w_ = 0.0, phase_ = 0.0;
    float Sm_ = 0.0f, Sp_ = 0.0f, mu_ = 0.0f, a_ = 0.0f, b_ = 0.0f, fxs_ = 0.0f, fxc_ = 0.0f;
    bool valid_ = false;
};

// Broadband NLMS-FxLMS using a reference-mic signal and an identified S.
// Only useful when the anti-noise path is faster than the noise's acoustic
// path to the ear (see simulator results). Kept for experiments.
class BroadbandFxlms {
public:
    void configure(const std::vector<float>& sHat, int taps, float mu, int loopDelaySamples) {
        sHat_ = sHat;
        taps_ = taps;
        mu_ = mu / (1.0f + loopDelaySamples / 16.0f);
        w_.assign(taps, 0.0f);
        x_.resize(taps);
        fx_.resize(taps);
        xs_.resize((int)sHat.size());
        energy_ = 0.0f;
    }
    // ref: reference-mic sample, err: error-mic sample. Returns anti-noise.
    float process(float ref, float err) {
        x_.push(ref);
        xs_.push(ref);
        const float* xs = xs_.window();
        float f = 0.0f;
        for (size_t k = 0; k < sHat_.size(); ++k) f += sHat_[k] * xs[k];
        float oldest = fx_.window()[taps_ - 1];
        fx_.push(f);
        energy_ += f * f - oldest * oldest;
        if (energy_ < 0.0f) energy_ = 0.0f;
        const float* fx = fx_.window();
        float g = mu_ * err / (energy_ + 1e-3f);
        for (int k = 0; k < taps_; ++k) w_[k] -= g * fx[k];
        const float* x = x_.window();
        float y = 0.0f;
        for (int k = 0; k < taps_; ++k) y += w_[k] * x[k];
        return y;
    }

private:
    std::vector<float> sHat_, w_;
    int taps_ = 64;
    float mu_ = 0.05f, energy_ = 0.0f;
    History x_{1}, fx_{1}, xs_{1};
};

// Click-train round-trip latency meter. Call nextOut() for every output
// sample and feedIn() for every input sample. Latency is the distance in
// frames between a click being written and its first detection on the input.
// Accuracy is limited by how the two streams' frame counters are aligned;
// treat as approximate and cross-check with Google's OboeTester.
class LatencyMeter {
public:
    void configure(float fs, float amplitude) {
        fs_ = fs;
        amp_ = amplitude;
        period_ = (long)(fs * 0.5f);
        outN_ = inN_ = 0;
        lastClickOut_ = -1;
        count_ = 0;
        sum_ = 0.0;
        minv_ = 1e9;
        maxv_ = 0.0;
        noiseFloor_ = 0.0f;
        blank_ = 0;
        waiting_ = false;
    }
    float nextOut() {
        float v = 0.0f;
        long phase = outN_ % period_;
        if (phase < 4) {  // 4-sample click
            v = (phase % 2 == 0) ? amp_ : -amp_;
            if (phase == 0) { lastClickOut_ = outN_; waiting_ = true; }
        }
        ++outN_;
        return v;
    }
    void feedIn(float x) {
        float a = std::fabs(x);
        noiseFloor_ += 0.0005f * (a - noiseFloor_);
        if (waiting_ && lastClickOut_ >= 0) {
            float thr = std::max(0.02f * amp_, 6.0f * noiseFloor_);
            // ignore anything earlier than 1 ms after the click was written
            if (inN_ > lastClickOut_ + (long)(0.001f * fs_) && a > thr) {
                double ms = 1000.0 * (double)(inN_ - lastClickOut_) / fs_;
                if (ms < 400.0) {
                    ++count_;
                    sum_ += ms;
                    minv_ = std::min(minv_, ms);
                    maxv_ = std::max(maxv_, ms);
                    last_ = ms;
                }
                waiting_ = false;
            }
            if (inN_ > lastClickOut_ + (long)(0.4f * fs_)) waiting_ = false;  // missed
        }
        ++inN_;
    }
    int detections() const { return count_; }
    double lastMs() const { return last_; }
    double meanMs() const { return count_ ? sum_ / count_ : 0.0; }
    double minMs() const { return count_ ? minv_ : 0.0; }
    double maxMs() const { return count_ ? maxv_ : 0.0; }

private:
    float fs_ = 48000.0f, amp_ = 0.2f, noiseFloor_ = 0.0f;
    long period_ = 24000, outN_ = 0, inN_ = 0, lastClickOut_ = -1;
    int count_ = 0, blank_ = 0;
    bool waiting_ = false;
    double sum_ = 0.0, minv_ = 1e9, maxv_ = 0.0, last_ = 0.0;
};

}  // namespace anc
