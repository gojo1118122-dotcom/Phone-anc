// AncEngine.cpp - Oboe full-duplex engine + JNI for Phone ANC.
//
// One output stream (data callback) and one input stream (read non-blocking
// inside the output callback, the same pattern OboeTester uses). The mic is
// the ERROR sensor: it must be close to the earphone speaker for the
// narrowband FxLMS controller to mean anything.
#include <jni.h>
#include <android/log.h>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

#include <oboe/Oboe.h>

#include "dsp.h"

#define TAG "PhoneANC"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

namespace {

enum Mode { IDLE = 0, LATENCY = 1, SECPATH = 2, ANC_NB = 3, TONE = 4 };
constexpr float kHardCap = 0.15f;        // absolute output ceiling, never exceeded
constexpr int kDrainCallbacks = 12;      // discard input for the first callbacks
constexpr float kIdSeconds = 4.0f;
constexpr int kIdTaps = 256;
constexpr int kMaxProbeDelay = 16384;

using Clock = std::chrono::steady_clock;

class Engine : public oboe::AudioStreamDataCallback, public oboe::AudioStreamErrorCallback {
public:
    int start(int inId, int outId, int bursts) {
        std::lock_guard<std::mutex> lock(mu_);
        stopLocked();
        reset();

        oboe::AudioStreamBuilder ob;
        ob.setDirection(oboe::Direction::Output)
            ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
            ->setSharingMode(oboe::SharingMode::Exclusive)
            ->setFormat(oboe::AudioFormat::Float)
            ->setChannelCount(oboe::ChannelCount::Stereo)
            ->setChannelConversionAllowed(true)
            ->setFormatConversionAllowed(true)
            ->setUsage(oboe::Usage::Media)
            ->setDeviceId(outId)
            ->setDataCallback(this)
            ->setErrorCallback(this);
        oboe::Result r = ob.openStream(out_);
        if (r != oboe::Result::OK) {
            LOGE("open output failed: %s", oboe::convertToText(r));
            return (int)r;
        }

        // Input: try unprocessed, then voice recognition, then shared mode.
        const oboe::InputPreset presets[] = {oboe::InputPreset::Unprocessed,
                                             oboe::InputPreset::VoiceRecognition,
                                             oboe::InputPreset::Generic};
        r = oboe::Result::ErrorInternal;
        for (auto preset : presets) {
            for (auto share : {oboe::SharingMode::Exclusive, oboe::SharingMode::Shared}) {
                oboe::AudioStreamBuilder ib;
                ib.setDirection(oboe::Direction::Input)
                    ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
                    ->setSharingMode(share)
                    ->setFormat(oboe::AudioFormat::Float)
                    ->setChannelCount(oboe::ChannelCount::Mono)
                    ->setChannelConversionAllowed(true)
                    ->setFormatConversionAllowed(true)
                    ->setSampleRate(out_->getSampleRate())
                    ->setInputPreset(preset)
                    ->setDeviceId(inId);
                r = ib.openStream(in_);
                if (r == oboe::Result::OK) break;
            }
            if (r == oboe::Result::OK) break;
        }
        if (r != oboe::Result::OK) {
            LOGE("open input failed: %s", oboe::convertToText(r));
            out_->close();
            out_.reset();
            return (int)r;
        }

        out_->setBufferSizeInFrames(out_->getFramesPerBurst() * std::max(1, bursts));
        outCh_ = out_->getChannelCount();
        inCh_ = in_->getChannelCount();
        fs_ = (float)out_->getSampleRate();
        maxFrames_ = std::max(4096, out_->getBufferCapacityInFrames());
        inBuf_.assign((size_t)maxFrames_ * inCh_, 0.0f);
        probeLine_.assign(kMaxProbeDelay, 0.0f);

        r = in_->requestStart();
        if (r == oboe::Result::OK) r = out_->requestStart();
        if (r != oboe::Result::OK) {
            LOGE("start failed: %s", oboe::convertToText(r));
            stopLocked();
            return (int)r;
        }
        running_ = true;
        return 0;
    }

    void stop() {
        std::lock_guard<std::mutex> lock(mu_);
        stopLocked();
    }

    // Immediate stop: silence on the very next callback, then close streams.
    void emergencyStop() {
        estop_.store(true);
        requestedMode_.store(IDLE);
        stop();
    }

    void setMode(int m) {
        if (m != IDLE) estop_.store(false);
        statusMsg_.store(0);
        requestedMode_.store(m);
    }

    void setParams(float freq, float limit, float toneGain, int probeOffset, float phaseDeg) {
        freq_.store(std::max(20.0f, std::min(freq, 2000.0f)));
        limit_.store(std::max(0.0f, std::min(limit, kHardCap)));
        toneGain_.store(std::max(0.0f, std::min(toneGain, 1.0f)));
        probeOffset_.store(std::max(0, std::min(probeOffset, kMaxProbeDelay - 1)));
        tonePhase_.store(phaseDeg);
    }

    // ---- audio callback ----
    oboe::DataCallbackResult onAudioReady(oboe::AudioStream*, void* audioData,
                                          int32_t numFrames) override {
        auto t0 = Clock::now();
        float* out = static_cast<float*>(audioData);
        if (estop_.load() || numFrames > maxFrames_ || !in_) {
            std::memset(out, 0, sizeof(float) * (size_t)numFrames * outCh_);
            return oboe::DataCallbackResult::Continue;
        }

        // ---- input ----
        int32_t got = 0;
        if (cbCount_ < kDrainCallbacks) {
            for (int i = 0; i < 8; ++i) {
                auto rr = in_->read(inBuf_.data(), maxFrames_, 0);
                if (!rr || rr.value() <= 0) break;
            }
            std::fill(inBuf_.begin(), inBuf_.begin() + (size_t)numFrames * inCh_, 0.0f);
        } else {
            auto rr = in_->read(inBuf_.data(), numFrames, 0);
            got = rr ? rr.value() : 0;
            if (got < numFrames) {
                std::fill(inBuf_.begin() + (size_t)got * inCh_,
                          inBuf_.begin() + (size_t)numFrames * inCh_, 0.0f);
                shortReads_.fetch_add(1);
            }
        }
        ++cbCount_;

        // ---- mode change (applied here so DSP state is single-threaded) ----
        int req = requestedMode_.load();
        if (req != mode_) applyMode(req);

        const float lim = std::min(limit_.load(), kHardCap);
        const float rampStep = 1.0f / (0.25f * fs_);
        const float freq = freq_.load();
        const float toneGain = toneGain_.load();
        const float toneW = 2.0f * (float)M_PI * freq / fs_;
        const float tonePh = tonePhase_.load() * (float)M_PI / 180.0f;
        const int off = std::min(probeOffset_.load(), kMaxProbeDelay - 1);

        int clipped = 0;
        for (int i = 0; i < numFrames; ++i) {
            float raw = inBuf_[(size_t)i * inCh_];
            // DC blocker on the mic
            float mic = raw - dcX_ + 0.995f * dcY_;
            dcX_ = raw;
            dcY_ = mic;

            // runaway/feedback guard: mic pinned near full scale
            if (std::fabs(raw) > 0.95f) {
                if (++hotRun_ > 200) tripGuard(1);
            } else {
                hotRun_ = 0;
            }

            float y = 0.0f;
            switch (mode_) {
                case LATENCY:
                    latency_.feedIn(raw);
                    y = latency_.nextOut();
                    break;
                case SECPATH:
                    y = rnd();  // scaled to the output limit below
                    break;
                case ANC_NB:
                    y = nb_.process(mic);
                    break;
                case TONE:
                    y = toneGain * std::sin(toneW * (float)tonePos_ + tonePh);
                    tonePos_ = (tonePos_ + 1) % (long)(fs_ * 1000.0f);
                    break;
                default:
                    break;
            }

            if (ramp_ < 1.0f) ramp_ = std::min(1.0f, ramp_ + rampStep);
            float v = y * ramp_;
            if (mode_ == SECPATH) v *= lim;  // probe uses the full user limit
            if (std::fabs(v) > lim) { v = anc::clampf(v, lim); ++clipped; }
            for (int c = 0; c < outCh_; ++c) out[(size_t)i * outCh_ + c] = v;

            // Identify the path from what was ACTUALLY played (post ramp and
            // limiter), delayed so a short filter covers the loop delay.
            if (mode_ == SECPATH) {
                probeLine_[probePos_] = v;
                int rd = probePos_ - off;
                if (rd < 0) rd += kMaxProbeDelay;
                float delayed = probeLine_[rd];
                probePos_ = (probePos_ + 1) % kMaxProbeDelay;
                id_.process(delayed, mic);
                if (++idCount_ >= (long)(kIdSeconds * fs_)) {
                    finishId(off);
                    // finishId switched to IDLE: silence the rest of this buffer
                    for (int j = i + 1; j < numFrames; ++j)
                        for (int c = 0; c < outCh_; ++c) out[(size_t)j * outCh_ + c] = 0.0f;
                    break;
                }
            }
        }

        // output saturation guard: ANC controller is fighting itself
        if (mode_ == ANC_NB) {
            clipWindow_ += clipped;
            frameWindow_ += numFrames;
            if (frameWindow_ >= (int)(0.1f * fs_)) {
                if (clipWindow_ > frameWindow_ / 4) tripGuard(2);
                clipWindow_ = frameWindow_ = 0;
            }
        }

        // CPU load estimate: callback time / buffer duration
        double usec = std::chrono::duration<double, std::micro>(Clock::now() - t0).count();
        double bufUs = 1e6 * numFrames / fs_;
        double load = 100.0 * usec / bufUs;
        cpuAvg_.store(cpuAvg_.load() * 0.98 + load * 0.02);
        if (load > cpuPeak_.load()) cpuPeak_.store(load);
        lastBurst_.store(numFrames);
        return oboe::DataCallbackResult::Continue;
    }

    void onErrorBeforeClose(oboe::AudioStream*, oboe::Result r) override {
        LOGE("stream error: %s", oboe::convertToText(r));
        requestedMode_.store(IDLE);
        estop_.store(true);
        disconnected_.store(true);
    }

    // Mean measured round-trip latency in ms (0 if none yet) and stream rate.
    double latencyMeanMs() { return latency_.meanMs(); }
    int sampleRate() { return (int)fs_; }

    std::string stats() {
        std::lock_guard<std::mutex> lock(mu_);
        char b[1800];
        int n = 0;
        auto add = [&](const char* fmt, auto... a) {
            if (n < (int)sizeof(b) - 200) n += std::snprintf(b + n, sizeof(b) - n, fmt, a...);
        };
        if (!running_ || !out_ || !in_) {
            add("%s", "Streams: stopped\n");
            if (disconnected_.load()) add("%s", "!! Device disconnected / stream error\n");
            return b;
        }
        auto lat = out_->calculateLatencyMillis();
        add("API: %s | rate %d Hz\n", oboe::convertToText(out_->getAudioApi()), out_->getSampleRate());
        add("OUT dev %d  %s  %s  ch%d\n", out_->getDeviceId(), oboe::convertToText(out_->getPerformanceMode()),
            oboe::convertToText(out_->getSharingMode()), out_->getChannelCount());
        add("   burst %d fr, buffer %d fr (%.1f ms)\n", out_->getFramesPerBurst(), out_->getBufferSizeInFrames(),
            1000.0 * out_->getBufferSizeInFrames() / fs_);
        add("IN  dev %d  %s  %s  preset %s\n", in_->getDeviceId(), oboe::convertToText(in_->getPerformanceMode()),
            oboe::convertToText(in_->getSharingMode()), oboe::convertToText(in_->getInputPreset()));
        add("   in burst %d fr\n", in_->getFramesPerBurst());
        if (lat) add("Output-side HAL latency est: %.1f ms\n", lat.value());
        auto xr = out_->getXRunCount();
        add("xruns out %d | short input reads %d\n", xr ? xr.value() : -1, shortReads_.load());
        add("CPU avg %.1f%%  peak %.1f%% of callback budget\n", cpuAvg_.load(), cpuPeak_.load());
        add("Mode: %d  ramp %.2f\n", requestedMode_.load(), ramp_);
        if (latency_.detections() > 0)
            add("ROUND TRIP: last %.1f  mean %.1f  min %.1f  max %.1f ms (n=%d)\n", latency_.lastMs(),
                latency_.meanMs(), latency_.minMs(), latency_.maxMs(), latency_.detections());
        if (idDone_.load()) {
            add("PATH ID: residual %.1f dB, peak %.3f at %.1f ms (offset %d + tap %d)\n", idResidualDb_.load(),
                idPeak_.load(), 1000.0 * (idOffset_ + idPeakIdx_) / fs_, idOffset_, idPeakIdx_);
            add("   %s\n", idOk_.load() ? "path looks usable" : "NOT usable: mic does not hear speaker clearly");
        }
        if (requestedMode_.load() == ANC_NB)
            add("ANC: %.0f Hz, mu %.5f, anti-noise amp %.3f\n", freq_.load(), nb_.step(), nb_.amplitude());
        int g = guard_.load();
        if (g == 1) add("%s", "!! STOPPED: mic saturated (feedback?)\n");
        if (g == 2) add("%s", "!! STOPPED: output saturated (not converging)\n");
        if (g == 3) add("%s", "!! Run PATH ID first (needs a usable result)\n");
        if (disconnected_.load()) add("%s", "!! Device disconnected / stream error\n");
        return b;
    }

private:
    void reset() {
        cbCount_ = 0;
        mode_ = IDLE;
        requestedMode_.store(IDLE);
        estop_.store(false);
        disconnected_.store(false);
        guard_.store(0);
        shortReads_.store(0);
        cpuAvg_.store(0);
        cpuPeak_.store(0);
        dcX_ = dcY_ = 0;
        hotRun_ = 0;
        clipWindow_ = frameWindow_ = 0;
        ramp_ = 0;
        // A path identified on a previous stream/device must not be reused.
        idDone_.store(false);
        idOk_.store(false);
        idOffset_ = idPeakIdx_ = 0;
    }

    void stopLocked() {
        running_ = false;
        if (in_) { in_->requestStop(); }
        if (out_) { out_->requestStop(); out_->close(); out_.reset(); }
        if (in_) { in_->close(); in_.reset(); }
    }

    void applyMode(int m) {
        mode_ = m;
        ramp_ = 0.0f;
        guard_.store(0);
        clipWindow_ = frameWindow_ = hotRun_ = 0;
        switch (m) {
            case LATENCY:
                latency_.configure(fs_, std::min(limit_.load(), kHardCap));
                break;
            case SECPATH:
                id_.configure(kIdTaps, 0.3f);
                idCount_ = 0;
                probePos_ = 0;
                std::fill(probeLine_.begin(), probeLine_.end(), 0.0f);
                idDone_.store(false);
                break;
            case ANC_NB:
                if (!idOk_.load()) {
                    guard_.store(3);
                    mode_ = IDLE;
                    requestedMode_.store(IDLE);
                    break;
                }
                {
                    auto S = id_.gainAt(freq_.load(), fs_, idOffset_);
                    nb_.configure(freq_.load(), fs_, S, 0.05f, idOffset_ + idPeakIdx_);
                    if (!nb_.valid()) {
                        guard_.store(3);
                        mode_ = IDLE;
                        requestedMode_.store(IDLE);
                    }
                }
                break;
            case TONE:
                tonePos_ = 0;
                break;
            default:
                break;
        }
    }

    void finishId(int off) {
        idOffset_ = off;
        idPeakIdx_ = id_.peakIndex();
        idPeak_.store(id_.peakMagnitude());
        idResidualDb_.store(id_.residualDb());
        idOk_.store(id_.residualDb() < -10.0f && id_.peakMagnitude() > 0.005f);
        idDone_.store(true);
        mode_ = IDLE;
        requestedMode_.store(IDLE);
    }

    void tripGuard(int code) {
        guard_.store(code);
        mode_ = IDLE;
        requestedMode_.store(IDLE);
        nb_.reset();
    }

    float rnd() {  // xorshift32 -> [-1, 1)
        rng_ ^= rng_ << 13;
        rng_ ^= rng_ >> 17;
        rng_ ^= rng_ << 5;
        return (float)(int32_t)rng_ / 2147483648.0f;
    }

    std::mutex mu_;
    std::shared_ptr<oboe::AudioStream> out_, in_;
    bool running_ = false;
    int outCh_ = 2, inCh_ = 1, maxFrames_ = 4096;
    float fs_ = 48000.0f;
    std::vector<float> inBuf_, probeLine_;

    // control (UI thread -> audio thread)
    std::atomic<int> requestedMode_{IDLE};
    std::atomic<bool> estop_{false}, disconnected_{false};
    std::atomic<float> freq_{100.0f}, limit_{0.03f}, toneGain_{0.5f}, tonePhase_{0.0f};
    std::atomic<int> probeOffset_{0}, guard_{0}, shortReads_{0}, statusMsg_{0};

    // audio-thread state
    int mode_ = IDLE;
    long cbCount_ = 0, tonePos_ = 0, idCount_ = 0;
    int probePos_ = 0, hotRun_ = 0, clipWindow_ = 0, frameWindow_ = 0;
    float ramp_ = 0.0f, dcX_ = 0.0f, dcY_ = 0.0f;
    uint32_t rng_ = 2463534242u;
    anc::LatencyMeter latency_;
    anc::SecondaryPathId id_{kIdTaps, 0.3f};
    anc::NarrowbandFxlms nb_;
    int idOffset_ = 0, idPeakIdx_ = 0;

    // diagnostics
    std::atomic<double> cpuAvg_{0}, cpuPeak_{0};
    std::atomic<int> lastBurst_{0};
    std::atomic<bool> idDone_{false}, idOk_{false};
    std::atomic<float> idResidualDb_{0}, idPeak_{0};
};

Engine& engine() {
    static Engine e;
    return e;
}

}  // namespace

extern "C" {

JNIEXPORT jint JNICALL Java_com_example_phoneanc_NativeBridge_nativeStart(JNIEnv*, jobject, jint inId,
                                                                           jint outId, jint bursts) {
    return engine().start(inId, outId, bursts);
}
JNIEXPORT void JNICALL Java_com_example_phoneanc_NativeBridge_nativeStop(JNIEnv*, jobject) { engine().stop(); }
JNIEXPORT void JNICALL Java_com_example_phoneanc_NativeBridge_nativeEmergencyStop(JNIEnv*, jobject) {
    engine().emergencyStop();
}
JNIEXPORT void JNICALL Java_com_example_phoneanc_NativeBridge_nativeSetMode(JNIEnv*, jobject, jint m) {
    engine().setMode(m);
}
JNIEXPORT void JNICALL Java_com_example_phoneanc_NativeBridge_nativeSetParams(JNIEnv*, jobject, jfloat freq,
                                                                               jfloat limit, jfloat toneGain,
                                                                               jint probeOffset, jfloat phaseDeg) {
    engine().setParams(freq, limit, toneGain, probeOffset, phaseDeg);
}
JNIEXPORT jdouble JNICALL Java_com_example_phoneanc_NativeBridge_nativeLatencyMeanMs(JNIEnv*, jobject) {
    return engine().latencyMeanMs();
}
JNIEXPORT jint JNICALL Java_com_example_phoneanc_NativeBridge_nativeSampleRate(JNIEnv*, jobject) {
    return engine().sampleRate();
}
JNIEXPORT jstring JNICALL Java_com_example_phoneanc_NativeBridge_nativeStats(JNIEnv* env, jobject) {
    return env->NewStringUTF(engine().stats().c_str());
}

}  // extern "C"
