// Host-side test of dsp.h against a simulated acoustic loop (NOT hardware).
// Build: g++ -O2 -std=c++17 -I../app/src/main/cpp host_test.cpp -o host_test
#include <cstdio>
#include <deque>
#include <random>
#include "dsp.h"

static const float FS = 48000.0f;

// Simulated speaker->error-mic path: pure delay + one-pole low-pass.
struct SimPath {
    std::deque<float> line;
    float lp = 0.0f, a;
    explicit SimPath(int delaySamples) {
        line.assign(delaySamples + 1, 0.0f);
        a = std::exp(-2.0f * (float)M_PI * 4000.0f / FS);
    }
    float run(float x) {
        line.push_back(x);
        float d = line.front();
        line.pop_front();
        lp = a * lp + (1.0f - a) * d;
        return lp;
    }
};

static double db(double p, double ref) { return 10.0 * std::log10((p + 1e-20) / (ref + 1e-20)); }

int main() {
    std::mt19937 rng(1);
    std::normal_distribution<float> nd(0.0f, 1.0f);
    const float sensor = std::pow(10.0f, -60.0f / 20.0f);
    printf("HOST SIMULATION of the real dsp.h code (not hardware)\n\n");

    printf("1) Secondary-path ID + narrowband FxLMS (tone, error mic at ear)\n");
    printf("%9s %9s %12s %12s %10s\n", "delay ms", "freq Hz", "ID resid dB", "atten dB", "mu");
    for (float dms : {0.5f, 2.0f, 5.0f, 10.0f, 20.0f}) {
        for (float f : {100.0f, 200.0f, 400.0f}) {
            int ds = (int)std::lround(dms * 1e-3f * FS);
            // phase A: identify S with white-noise probe
            SimPath idPath(ds);
            anc::SecondaryPathId id(1024, 0.3f);
            for (int n = 0; n < (int)(FS * 4); ++n) {
                float probe = 0.1f * nd(rng);
                float mic = idPath.run(probe) + sensor * nd(rng);
                id.process(probe, mic);
            }
            auto S = id.gainAt(f, FS);
            // phase B: run ANC against a tone disturbance
            SimPath path(ds);
            anc::NarrowbandFxlms nb;
            nb.configure(f, FS, S, 0.05f, ds);
            double pd = 0, pe = 0;
            float y = 0.0f, w = 2.0f * (float)M_PI * f / FS;
            int N = (int)(FS * 4);
            for (int n = 0; n < N; ++n) {
                float d = std::sin(w * n + 0.7f);
                float e = d + path.run(y) + sensor * nd(rng);
                y = nb.process(e);
                if (n > N * 3 / 4) { pd += d * d; pe += e * e; }
            }
            printf("%9.1f %9.0f %12.1f %12.1f %10.5f\n", dms, f, id.residualDb(), db(pe, pd), nb.step());
        }
    }

    printf("\n2) Latency meter vs known simulated loop delay\n");
    for (float dms : {5.0f, 12.0f, 25.0f, 40.0f}) {
        int ds = (int)std::lround(dms * 1e-3f * FS);
        std::deque<float> line(ds, 0.0f);
        anc::LatencyMeter lm;
        lm.configure(FS, 0.2f);
        for (int n = 0; n < (int)(FS * 5); ++n) {
            float out = lm.nextOut();
            line.push_back(out);
            float in = line.front() + 0.001f * nd(rng);
            line.pop_front();
            lm.feedIn(in);
        }
        printf("true %.1f ms -> measured mean %.2f ms (n=%d, min %.2f, max %.2f)\n", dms,
               lm.meanMs(), lm.detections(), lm.minMs(), lm.maxMs());
    }

    printf("\n3) Broadband FxLMS, primary delay 0.5 ms (reference = noise at mic)\n");
    printf("%12s %10s\n", "sec delay ms", "atten dB");
    for (float dms : {0.02f, 0.1f, 0.25f, 1.0f, 5.0f}) {
        int ds = (int)std::lround(dms * 1e-3f * FS);
        int dp = (int)std::lround(0.5e-3f * FS);
        SimPath path(ds);
        // true S for the controller: measure its impulse response
        // The loop feeds y into the path one sample late, so the true loop
        // response is the path response shifted by one sample. On a device the
        // identification step measures the whole loop; mimic that here.
        std::vector<float> sHat(128, 0.0f);
        {
            SimPath p(ds);
            for (int k = 0; k < 127; ++k) sHat[k + 1] = p.run(k == 0 ? 1.0f : 0.0f);
        }
        anc::BroadbandFxlms bb;
        bb.configure(sHat, 64, 0.1f, ds);
        std::deque<float> pdel(dp, 0.0f);
        float y = 0.0f;
        double pd = 0, pe = 0;
        int N = (int)(FS * 2);
        for (int n = 0; n < N; ++n) {
            float x = nd(rng);
            pdel.push_back(x);
            float d = pdel.front();
            pdel.pop_front();
            float e = d + path.run(y) + sensor * nd(rng);
            y = bb.process(x, e);
            if (n > N * 3 / 4) { pd += d * d; pe += e * e; }
        }
        printf("%12.2f %10.1f\n", dms, db(pe, pd));
    }
        printf("\n4) Long loop (realistic Android 25 ms) with probe offset, 256-tap ID\n");
    printf("%9s %12s %12s %10s\n", "freq Hz", "ID resid dB", "atten dB", "est delay");
    for (float f : {100.0f, 200.0f, 400.0f}) {
        int ds = (int)std::lround(25e-3f * FS);
        int off = ds - 32;
        SimPath idPath(ds);
        anc::SecondaryPathId id(256, 0.3f);
        std::deque<float> pd(off, 0.0f);
        for (int n = 0; n < (int)(FS * 4); ++n) {
            float probe = 0.1f * nd(rng);
            pd.push_back(probe);
            float delayed = pd.front();
            pd.pop_front();
            float mic = idPath.run(probe) + sensor * nd(rng);
            id.process(delayed, mic);
        }
        auto S = id.gainAt(f, FS, off);
        int total = id.peakIndex() + off;
        SimPath path(ds);
        anc::NarrowbandFxlms nb;
        nb.configure(f, FS, S, 0.05f, total);
        double pdp = 0, pe = 0;
        float y = 0.0f, w = 2.0f * (float)M_PI * f / FS;
        int N = (int)(FS * 6);
        for (int n = 0; n < N; ++n) {
            float d = std::sin(w * n + 0.7f);
            float e = d + path.run(y) + sensor * nd(rng);
            y = nb.process(e);
            if (n > N * 3 / 4) { pdp += d * d; pe += e * e; }
        }
        printf("%9.0f %12.1f %12.1f %8.1f ms\n", f, id.residualDb(), db(pe, pdp), 1000.0 * total / FS);
    }
    return 0;
}
